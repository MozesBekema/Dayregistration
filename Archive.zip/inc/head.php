<head>
    <link href="css/styles.css" rel="stylesheet" type="text/css">
    <link href="css/material.css" rel="stylesheet" type="text/css">
    <script src="js/material.min.js" type="text/javascript"></script>
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700" type="text/css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="img/logo.png">
</head>
