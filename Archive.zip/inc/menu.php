<header class="mdl-layout__header">
                <div class="mdl-layout__header-row"> <span class="mdl-layout-title">Day Registration</span>
                    <!-- Title -->
                    <!-- Add spacer, to align navigation to the right -->
                    <div class="mdl-layout-spacer"></div>
                    <!-- Navigation. We hide it in small screens. -->
                    <nav class="mdl-navigation mdl-layout--large-screen-only">
                        <?php include("link.php") ?>
                    </nav>
                </div>
            </header>
            <div class="mdl-layout__drawer"> <span class="mdl-layout-title"><a href="index.php"><img src="img/logo.png"></a>Day Registration</span>
                <nav class="mdl-navigation mdl-js-ripple-effect">
                    <?php include("link.php") ?>
                </nav>
            </div>

